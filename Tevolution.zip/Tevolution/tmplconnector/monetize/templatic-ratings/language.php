<?php
/*rating language file*/
define('RATING_MODULE_URLPATH',__(plugin_dir_url( __FILE__ ),DOMAIN));
?>